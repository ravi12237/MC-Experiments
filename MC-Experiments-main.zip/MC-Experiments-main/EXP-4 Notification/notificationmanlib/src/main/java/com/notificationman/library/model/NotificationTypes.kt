package com.notificationman.library.model

enum class NotificationTypes(val type: Int) {
    TEXT(0),
    IMAGE(1)
}