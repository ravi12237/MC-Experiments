package io.ak1.drawboxsample.ui.theme

import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF4E33FF)
val WhiteDark = Color(0xFFF9F9F9)
val WhiteLite = Color(0xFFFFFFFF)
val BlackDark = Color(0xFF0E121B)
val BlackLite = Color(0xFF171C26)
val Grey = Color(0xFF586070)
